
package com.icinbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcinbankNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
